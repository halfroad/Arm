#ifndef __SYSTEM_INITIALIZER_H
#define __SYSTEM_INITIALIZER_H

#include <stm32h7xx_hal.h>

void SystemClock_Config(void);
    
#endif

