#ifndef __TASKS_WRAPPER_H
#define __TASKS_WRAPPER_H

#include <stm32h7xx.h>

#endif