#include "FreeRTOS.h"
#include "TasksWrapper.h"

void vGenerateM7ToM4Interrupt( void * xUpdatedMessageBuffer )
{
}

void vApplicationGetIdleTaskMemory( StaticTask_t **ppxIdleTaskTCBBuffer, StackType_t **ppxIdleTaskStackBuffer, uint32_t *pulIdleTaskStackSize )
{
    
}