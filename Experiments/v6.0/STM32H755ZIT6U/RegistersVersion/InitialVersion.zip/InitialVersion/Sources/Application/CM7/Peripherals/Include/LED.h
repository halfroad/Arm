#ifndef LED_H
#define LED_H

#include <stm32h7xx.h>

void InitLEDs(void);

#endif