#ifndef __Tasks_Wrapper_h
#define __Tasks_Wrapper_h

void InitFreeRTOS(void);
    
#endif