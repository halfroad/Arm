#include <math.h>

#include "../Include/AnalogyDigitalConversion.h"

/*

Table 12. STM32G474xB/xC/xE pin definition (continued)

Pin name        Alternate unctions          Functions on ATK Motor Drive Board

PB1             ADC3_IN1 / ADC1_IN12        PM2_VBUS, Voltage Sensor of DC with/o Motor Connector 2.
PE7             ADC3_IN4                    PM2_AMPU, U Phase Current Sensor of DC with/o Motor Connector 2.
PE8(Not Used)   ADC345_IN6                  PM2_AMPV, V Phase Current Sensor of DC with/o Motor Connector 2.
PE9             ADC3_IN2                    PM2_VTEMP, Temperature Sensor of DC with/o Motor Connector 2.
PE10(Not Used)  ADC345_IN14                 PM2_AMPW, W Phase Current Sensor of DC with/o Motor Connector 2.

*/

/* ADCx settings. */
#define ADC_INSTANCE                                                ADC3
#define ADC_INSTANCE_CLOCK_ENABLE()                                 do { __HAL_RCC_ADC345_CLK_ENABLE(); } while (0)

/* PM2_VBUS, Voltage Sensor of DC with/o Motor Connector 2. */
#define VBUS_VOLTAGE_SENSOR_GPIO_PORT                               GPIOB
#define VBUS_VOLTAGE_SENSOR_GPIO_PIN                                GPIO_PIN_1
#define VBUS_VOLTAGE_SENSOR_GPIO_CLOCK_ENABLE()                     do { __HAL_RCC_GPIOB_CLK_ENABLE(); } while (0)
#define VBUS_VOLTAGE_SENSOR_ADC_CHANNEL                             ADC_CHANNEL_1

/* U Phase Current Sensor of DC with/o Motor Connector 2.. */
#define PHASE_U_CURRENT_SENSOR_GPIO_PORT                            GPIOE
#define PHASE_U_CURRENT_SENSOR_GPIO_PIN                             GPIO_PIN_7
#define PHASE_U_CURRENT_SENSOR_GPIO_CLOCK_ENABLE()                  do { __HAL_RCC_GPIOE_CLK_ENABLE(); } while (0)
#define PHASE_U_CURRENT_SENSOR_ADC_CHANNEL                          ADC_CHANNEL_4

/* PM2_VTEMP, Temperature Sensor of DC with/o Motor Connector 2. */
/* #define TEMPERATURE_SENSOR_GPIO_PORT                                GPIOE */
#define TEMPERATURE_SENSOR_GPIO_PIN                                 GPIO_PIN_9
/* #define TEMPERATURE_SENSOR_GPIO_CLOCK_ENABLE()                      do { __HAL_RCC_GPIOE_CLK_ENABLE(); } while(0) */
#define TEMPERATURE_SENSOR__ADC_CHANNEL                             ADC_CHANNEL_2

#define ADC_INSTANCE_DMA                                            DMA1
#define ADC_INSTANCE_DMA_CHANNEL                                    DMA1_Channel1
#define ADC_INSTANCE_DMA_CHANNEL_IRQN                               DMA1_Channel1_IRQn
#define ADC_INSTANCE_DMA_REQUEST                                    DMA_REQUEST_ADC3
#define ADC_DMA_Channel_IRQHandler                                  DMA1_Channel1_IRQHandler

ADC_HandleTypeDef ADC_HandleType = { 0 };
DMA_HandleTypeDef DMA_HandleType = { 0 };

uint16_t gatheredConversions[ADC_CHANNELS_NUMBER * ADC_GATHER_TIMES_PER_CHANNEL];
uint16_t averageConversions[ADC_CHANNELS_NUMBER];

const float Rp = 10000.0f;
const float T2 = 273.15f + 25.0f;
const float Bx = 3380.0f;
const float Ka = 273.15f;

static void InitDirectMemoryAccess(void);
static void ConfigAnalogyDigitalConversionChannel(uint32_t channel, uint32_t rank, uint32_t samplingTime);

void InitAnalogyDigitalConversion(void)
{
    InitDirectMemoryAccess();
    
    /* ADC_HandleTypeDef ADC_HandleType = { 0 }; */
    
    ADC_HandleType.Instance = ADC_INSTANCE;
    
    ADC_HandleType.Init.ClockPrescaler = ADC_CLOCK_SYNC_PCLK_DIV4;  /* 170MHz / 4. */
    ADC_HandleType.Init.Resolution = ADC_RESOLUTION_12B;
    ADC_HandleType.Init.DataAlign = ADC_DATAALIGN_RIGHT;
    ADC_HandleType.Init.GainCompensation = 0x00U;
    ADC_HandleType.Init.ScanConvMode = ADC_SCAN_ENABLE;
    ADC_HandleType.Init.EOCSelection = ADC_EOC_SEQ_CONV;
    ADC_HandleType.Init.LowPowerAutoWait = DISABLE;
    ADC_HandleType.Init.ContinuousConvMode = ENABLE;
    ADC_HandleType.Init.NbrOfConversion = 3;
    ADC_HandleType.Init.DiscontinuousConvMode = DISABLE;
    ADC_HandleType.Init.NbrOfDiscConversion = 0;
    ADC_HandleType.Init.ExternalTrigConv = ADC_SOFTWARE_START;
    ADC_HandleType.Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_NONE;
    ADC_HandleType.Init.DMAContinuousRequests = ENABLE;
    ADC_HandleType.Init.Overrun = ADC_OVR_DATA_OVERWRITTEN;
    ADC_HandleType.Init.OversamplingMode = DISABLE;
    
    /* ADC_HandleType.MspInitCallback = */
    
    HAL_ADC_Init(&ADC_HandleType);
    
    HAL_ADCEx_Calibration_Start(&ADC_HandleType, ADC_SINGLE_ENDED);
    
    ConfigAnalogyDigitalConversionChannel(VBUS_VOLTAGE_SENSOR_ADC_CHANNEL, ADC_REGULAR_RANK_1, ADC_SAMPLETIME_640CYCLES_5);
    ConfigAnalogyDigitalConversionChannel(PHASE_U_CURRENT_SENSOR_ADC_CHANNEL, ADC_REGULAR_RANK_2, ADC_SAMPLETIME_640CYCLES_5);
    ConfigAnalogyDigitalConversionChannel(TEMPERATURE_SENSOR__ADC_CHANNEL, ADC_REGULAR_RANK_3, ADC_SAMPLETIME_640CYCLES_5);
    
    /*
    
    #define __HAL_LINKDMA(__HANDLE__, __PPP_DMA_FIELD__, __DMA_HANDLE__) \
      do{                                                                \
        (__HANDLE__)->__PPP_DMA_FIELD__ = &(__DMA_HANDLE__);             \
        (__DMA_HANDLE__).Parent = (__HANDLE__);                          \
      } while(0)
  
    */
    __HAL_LINKDMA(&ADC_HandleType, DMA_Handle, DMA_HandleType);
    
    HAL_NVIC_SetPriority(ADC_INSTANCE_DMA_CHANNEL_IRQN, 10, 0);
    HAL_NVIC_EnableIRQ(ADC_INSTANCE_DMA_CHANNEL_IRQN);
    
    HAL_ADC_Start_DMA(&ADC_HandleType, (uint32_t *)gatheredConversions, ADC_CHANNELS_NUMBER * ADC_GATHER_TIMES_PER_CHANNEL);

}

/**
  * @brief  Initialize the ADC MSP.
  * @param hadc ADC handle
  * @retval None
  */
void HAL_ADC_MspInit(ADC_HandleTypeDef *hadc)
{
  /* Prevent unused argument(s) compilation warning */
  UNUSED(hadc);

  /* NOTE : This function should not be modified. When the callback is needed,
            function HAL_ADC_MspInit must be implemented in the user file.
   */
    
    if (hadc -> Instance == ADC_INSTANCE)
    {
        RCC_PeriphCLKInitTypeDef RCC_PeriphCLKInitType = { 0 };
        
        /* Set the clock source of ADCx. */
        RCC_PeriphCLKInitType.PeriphClockSelection = RCC_PERIPHCLK_ADC345;
        RCC_PeriphCLKInitType.Adc345ClockSelection = RCC_ADC345CLKSOURCE_SYSCLK;
        
        HAL_RCCEx_PeriphCLKConfig(&RCC_PeriphCLKInitType);
        
        /* Enable ADCx Clock. */
        ADC_INSTANCE_CLOCK_ENABLE();
        
        GPIO_InitTypeDef GPIO_InitType = { 0 };
        
        GPIO_InitType.Pin = VBUS_VOLTAGE_SENSOR_GPIO_PIN;
        GPIO_InitType.Mode = GPIO_MODE_ANALOG;
        GPIO_InitType.Pull = GPIO_NOPULL;
        
        /* Enable GPIO clocks for Voltage Sensor. */
        VBUS_VOLTAGE_SENSOR_GPIO_CLOCK_ENABLE();
        HAL_GPIO_Init(VBUS_VOLTAGE_SENSOR_GPIO_PORT, &GPIO_InitType);
        
        /* Enable GPIO clocks for Current Sensor. */
        PHASE_U_CURRENT_SENSOR_GPIO_CLOCK_ENABLE();
        GPIO_InitType.Pin = PHASE_U_CURRENT_SENSOR_GPIO_PIN | TEMPERATURE_SENSOR_GPIO_PIN;
        
        HAL_GPIO_Init(PHASE_U_CURRENT_SENSOR_GPIO_PORT, &GPIO_InitType);
    }
}

static void InitDirectMemoryAccess(void)
{
    __HAL_RCC_DMAMUX1_CLK_ENABLE();
    
    /* DMA_HandleTypeDef DMA_HandleType = { 0 }; */
    
    DMA_HandleType.Instance = ADC_INSTANCE_DMA_CHANNEL;
    
    DMA_HandleType.Init.Request = ADC_INSTANCE_DMA_REQUEST;
    DMA_HandleType.Init.Direction = DMA_PERIPH_TO_MEMORY;
    DMA_HandleType.Init.PeriphInc = DMA_PINC_DISABLE;
    DMA_HandleType.Init.MemInc = DMA_PINC_ENABLE;
    DMA_HandleType.Init.PeriphDataAlignment = DMA_PDATAALIGN_HALFWORD;  /* Length equals 6 bits. */
    DMA_HandleType.Init.MemDataAlignment = DMA_PDATAALIGN_HALFWORD;
    DMA_HandleType.Init.Mode = DMA_CIRCULAR;
    DMA_HandleType.Init.Priority = DMA_PRIORITY_MEDIUM;
    
    HAL_DMA_Init(&DMA_HandleType);
}


static void ConfigAnalogyDigitalConversionChannel(uint32_t channel, uint32_t rank, uint32_t samplingTime)
{
    /* Config the ADC channels. */
    ADC_ChannelConfTypeDef ADC_ChannelConfType = { 0 };
    
    ADC_ChannelConfType.Channel = channel;
    ADC_ChannelConfType.Rank = rank;
    ADC_ChannelConfType.SamplingTime = samplingTime;
    ADC_ChannelConfType.SingleDiff = ADC_SINGLE_ENDED;
    
    HAL_ADC_ConfigChannel(&ADC_HandleType, &ADC_ChannelConfType);
}

void ADC_DMA_Channel_IRQHandler(void)
{
    HAL_DMA_IRQHandler(&DMA_HandleType);
}

/**
  * @brief  Conversion complete callback in non-blocking mode.
  * @param hadc ADC handle
  * @retval None
  */
void HAL_ADC_ConvCpltCallback(ADC_HandleTypeDef *hadc)
{
  /* Prevent unused argument(s) compilation warning */
  UNUSED(hadc);

  /* NOTE : This function should not be modified. When the callback is needed,
            function HAL_ADC_ConvCpltCallback must be implemented in the user file.
   */
    
    if (hadc -> Instance == ADC_INSTANCE)
    {
        HAL_ADC_Stop_DMA(&ADC_HandleType);
        
        ComputeAnalogyDigitalConversions(averageConversions);
        
        HAL_ADC_Start_DMA(&ADC_HandleType, (uint32_t *)gatheredConversions, ADC_CHANNELS_NUMBER * ADC_GATHER_TIMES_PER_CHANNEL);
    }
}

void ComputeAnalogyDigitalConversions(uint16_t *averageConversions)
{
    uint32_t averages [3] = { 0, 0, 0 };
    
    for (uint16_t i = 0; i < ADC_GATHER_TIMES_PER_CHANNEL; i ++)
    {
        averages[0] += gatheredConversions[0 + i * ADC_CHANNELS_NUMBER];    /* Gathered voltages. */
        averages[1] += gatheredConversions[1 + i * ADC_CHANNELS_NUMBER];    /* Gathered temperatures. */
        averages[2] += gatheredConversions[2 + i * ADC_CHANNELS_NUMBER];    /* Gathered currents. */
    }
    
    averages[0] /= ADC_CHANNELS_NUMBER;
    averages[1] /= ADC_CHANNELS_NUMBER;
    averages[2] /= ADC_CHANNELS_NUMBER;
    
    averageConversions[0] = averages[0];
    averageConversions[1] = averages[1];
    averageConversions[2] = averages[2];
}

float AcquireTemperature(uint16_t conversion)
{
    float Rt = 3.3f * 4700.0f / (conversion * 3.3f / 4096.0f) - 4700.0f;
    float temperature = Rt / Rp;
    
    temperature = log(temperature);
    temperature /= Bx;
    temperature += 1.0f / T2;
    temperature = 1.0f / temperature;
    temperature -= Ka;
    
    return temperature;
    
}