#ifndef __SYSTEM_INITIALIZER_H
#define __SYSTEM_INITIALIZER_H

void SystemClock_Config(void);

#endif /* #ifndef __SYSTEM_INITIALIZER_H */