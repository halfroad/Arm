#ifndef __ANALOGY_DIGITAL_CONVERSION_H
#define __ANALOGY_DIGITAL_CONVERSION_H

#include <stm32g4xx.h>

#define ADC_CHANNELS_NUMBER                                         3
#define ADC_GATHER_TIMES_PER_CHANNEL                                1000


/* Current I = (ADC Now value - Initial ADC value) * (3.3f / 4.096f / 0.12f). */
#define CAST_ADC_TO_CURRENT                                         (float)(3.3f / 4.096f / 0.12f)

/* V_POWER = ADC * (3.3f * 25 / 4096). */
#define CAST_ADC_TO_VOLTAGE                                         (float)(3.3f * 25 / 4096)

void InitAnalogyDigitalConversion(void);

void ComputeAnalogyDigitalConversions(uint16_t *averageConversions);
float AcquireTemperature(uint16_t conversion);

#endif